"use client"
import React, { useState } from 'react';

// Define the type for our shop items
interface ShopItem {
  id: string;
  name: string;
  amount: number; // Represents the price of the item
}

// Dummy data for our shop items
const initialShopItems: ShopItem[] = [
  { id: 'minecraft:diamond', name: 'Diamond', amount: 10.0 },
  { id: 'minecraft:gold', name: 'Gold', amount: 6.4 },
  { id: 'minecraft:iron', name: 'Iron', amount: 3.4 },
  { id: 'minecraft:emerald', name: 'Emerald', amount: 8.00 },
];

const ShopPage: React.FC = () => {
  const [items, setItems] = useState<ShopItem[]>(initialShopItems);
  const [selectedItem, setSelectedItem] = useState<ShopItem | null>(null);
  const [quantity, setQuantity] = useState<number>(1);

  const handleItemClick = (item: ShopItem) => {
    setSelectedItem(item);
    setQuantity(1); // Reset quantity when a new item is selected
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value, 10);
    setQuantity(isNaN(value) || value < 1 ? 1 : value);
  };

  const handleAddToCart = () => {
    if (selectedItem) {
      console.log(
        `Adding ${quantity} of ${selectedItem.name} to cart. Total: $${(
          selectedItem.amount * quantity
        ).toFixed(2)}`,
      );
      // Here you'd typically dispatch an action to a global state (Redux, Context, etc.)
      // or make an API call. For now, we'll just log it.
      setSelectedItem(null); // Close the card after "adding"
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Tweaky.Shop</h1>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {items.map((item) => (
          <li
            key={item.id}
            onClick={() => handleItemClick(item)}
            style={{
              padding: '10px',
              margin: '5px 0',
              border: '1px solid #ccc',
              borderRadius: '5px',
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              backgroundColor:
                selectedItem?.id === item.id ? '#e0f7fa' : 'white',
            }}
          >
            <span>
              {item.name} (ID: {item.id})
            </span>
            <span>${item.amount.toFixed(2)}</span>
          </li>
        ))}
      </ul>

      {selectedItem && (
        <div
          style={{
            marginTop: '20px',
            padding: '20px',
            border: '2px solid #007bff',
            borderRadius: '8px',
            backgroundColor: '#f8f9fa',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
          }}
        >
          <h3>Purchasing: {selectedItem.name}</h3>
          <p>
            Price per unit: ${selectedItem.amount.toFixed(2)}
          </p>
          <label htmlFor="quantity">Quantity:</label>
          <input
            type="number"
            id="quantity"
            min="1"
            value={quantity}
            onChange={handleQuantityChange}
            style={{ marginLeft: '10px', padding: '5px', width: '60px' }}
          />
          <p>
            Total for {quantity} units:{' '}
            <strong>${(selectedItem.amount * quantity).toFixed(2)}</strong>
          </p>
          <button
            onClick={handleAddToCart}
            style={{
              padding: '10px 15px',
              backgroundColor: '#28a745',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              marginRight: '10px',
            }}
          >
            Add to Cart (the console)
          </button>
          <button
            onClick={() => setSelectedItem(null)}
            style={{
              padding: '10px 15px',
              backgroundColor: '#dc3545',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
            }}
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
};

export default ShopPage;
